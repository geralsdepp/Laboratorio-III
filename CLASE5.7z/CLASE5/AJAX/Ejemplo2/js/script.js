window.addEventListener('load', ()=>{
    document.getElementById('btnTraer').addEventListener('click', traerTexto);
});

function traerTexto(){
    let xhr = new XMLHttpRequest(); // objeto peticion

    xhr.onreadystatechange = ()=>{
    let info = document.getElementById('info');
        //ACA VA EL CODIGO QUE MANEJA LA PETICION
        if (xhr.readyState == 4) { //4 : finalizo la peticion
            if (xhr.status == 200) {

                setTimeout(() => {
                    let persona = JSON.parse(xhr.responseText);
                    info.innerText = `Nombre: ${persona.nombre} Apellido: ${persona.apellido} Edad: ${persona.edad}`;
                    clearTimeout(tiempo);
                }, 3000);
                
            }
            else{
                console.log(`Error: ${xhr.status} - ${xhr.statusText}`);
            }
        }
        else{
            info.innerHTML = '<img src="./images/spinner.gif" alt="spinner" />';
        }

    }
    xhr.open('GET', './persona.json', true);
    xhr.send();

    var tiempo = setTimeout(() => {
        
        xhr.abort();
        info.innerHTML = "Servidor ocupado. Intente mas tarde.";
    }, 4000);
}